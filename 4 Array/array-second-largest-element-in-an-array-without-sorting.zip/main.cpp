#include <iostream>
using namespace std;
int print2largest(int arr[], int n) {
	    // code here
	    int max= arr[0];
	    int S_max= -1;
	    for(int i=0;i<n;i++){
	        if(arr[i]>max){
	            S_max=max;
	            max=arr[i];
	        }
	        else {
	            if(arr[i] == max)
                    continue;
                if( arr[i] > S_max)
                    S_max = arr[i];
	        }
	    }
	    return S_max;
}

int main()
{
    int arr[10]={2,1,4,2,6,5,7,8,11,45};
    cout<<print2largest(arr, 10);

    return 0;
}