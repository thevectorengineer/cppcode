#include <iostream>
#include <climits>
using namespace std;

bool linearSearch(int find[], int n, int key){
    for(int i=0; i<n;i++){
        if(key==find[i]){
            return 1;
        }
    }
    return 0;
}

int main(){
    int size;
    cin>>size;
    int arr[100];
    for(int i=0; i<size;i++){
         cin>>arr[i];
    }
    int key;
    cin>>key;
    
    bool found= linearSearch(arr, size, key);
    
    if(found){
        cout<<"Found"<<endl;
    }
    else{
        cout<<"not found"<<endl;
    }
    return 0;
}

