#include <iostream>
using namespace std;

void swapAlt(int arr[], int n){
    for(int i=0; i<n;i+=2){
        if(i+1<n){
            swap(arr[i],arr[i+1]);
        }
    }
}
void printArr(int arr[], int n){
    for(int i=0; i<n; i++){
         cout<<arr[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int even[8]={5,-6,9,8,-7,2,-9,21};
    int odd[5]={1,-9,2,8,-5};
    swapAlt(even, 8);
    printArr(even, 8);
    swapAlt(odd, 5);
    printArr(odd, 5);
    return 0;
}