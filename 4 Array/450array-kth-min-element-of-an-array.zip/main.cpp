#include <iostream>
using namespace std;
void kthSmall(int arr[], int n, int k){
    sort(arr, arr+n);
    cout<<"small:"<<arr[k-1]<<endl;
}
int main(){
    int n=6;
    int k;
    cin>>k;
    int array[n]={7,10, 4, 3, 20, 15};
    kthSmall(array, n-1, k);
    return 0;
}