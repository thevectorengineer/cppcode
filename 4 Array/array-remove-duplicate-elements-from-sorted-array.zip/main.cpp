#include <iostream>
using namespace std;

int main(){
    int n=8;
    int arr[n]={1,1,2,2,2,3,4,4};
    // int temp[n];
    int j=0;
    for(int i=0; i<n-1;i++){
        if(arr[i]!=arr[i+1]){
            arr[j]=arr[i];
            j++;
        }
    }
    arr[j]=arr[n-1];
    
    for(int i=0;i<=j;i++){
        cout<<arr[i]<<" ";
    }

    return 0;
}