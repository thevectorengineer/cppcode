#include <iostream>
using namespace std;

void reverse(int arr[], int n){
    for(int i=0; i<n;i++){
        int s=0;
        int e=n-1;
        while(s<=e){
            swap(arr[s],arr[e]);
            s++;
            e--;
        }
    }
}

void printArr(int arr[], int n){
    for(int i=0; i<n;i++){
         cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main(){
    int size;
    cin>>size;
    int arr[100];
    for(int i=0; i<size;i++){
         cin>>arr[i];
    }
    reverse(arr, size);
    printArr(arr, size);
    return 0;
}

