#include <iostream>
using namespace std;

int binarySearch(int array[],int n, int key){
    int s=0, e=n;
    while(s<=e){
        int mid=s+((e-s)/2);
        if(array[mid]==key){
            return mid;
        }
        else if(array[mid]>key){
            e=mid-1;
        }
        else{
            s=mid+1;
        }
        mid=s+((e-s)/2);
    }
    return -1;
}
int main(){
    int even[8]={2,3,5,6,8,9,7,4};
    int odd[5]={7,55,333,2222,1111};
    cout<<binarySearch(even,8, 55)<<endl;
    cout<<binarySearch(even,8, 8)<<endl;
    cout<<binarySearch(odd,5, 55)<<endl;
    cout<<binarySearch(odd,5, 5)<<endl;
    return 0;
}
