#include <iostream>
using namespace std;

int main(){
    int n=6;
    int arr[n]={5,1,6,8,7,2};
    
    int temp=arr[0];
    for(int i=1; i<n; i++){
        arr[i-1]=arr[i];
    }
    arr[n-1]=temp;
    
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}