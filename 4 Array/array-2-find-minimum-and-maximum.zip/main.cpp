#include <iostream>
#include <climits>
using namespace std;

int printMax(int maxi[], int n){
    int mx= INT_MIN;
    for(int i=0; i<n;i++){
        mx = max(mx,maxi[i]);
    }
    return mx;
}
int printMin(int mini[], int n){
    int mn= INT_MAX;
    for(int i=0; i<n;i++){
        mn = min(mn,mini[i]);
    }
    return mn;
}

int main(){
    int size;
    cin>>size;
    int arr[100];
    for(int i=0; i<size;i++){
         cin>>arr[i];
    }
    cout<<"max: "<< printMax(arr, size)<<" ";
    cout<<"min: "<<printMin(arr, size)<<" ";
    return 0;
}

