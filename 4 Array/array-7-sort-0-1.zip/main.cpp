#include <iostream>
using namespace std;

void sort(int arr[], int n){
    int left=0, right=n-1;
    while(left<right){
        while(arr[left]==0 && left<right){
            left++;
        }
        while(arr[right]==1 && left<right){
            right--;
        }
        swap(arr[left],arr[right]);
        left++;
        right--;
    }
}

void printArr(int arr[], int n){
    for(int i=0; i<n; i++){
         cout<<arr[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int even[10]={0,1,1,0,1,1,1,0,0,0};
    int odd[5]={1,0,1,1,0};
    sort(even, 10);
    printArr(even, 10);
    sort(odd, 5);
    printArr(odd, 5);
    return 0;
}
