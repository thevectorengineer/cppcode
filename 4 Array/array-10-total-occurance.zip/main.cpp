#include <iostream>
using namespace std;

int first(int array[],int n, int key){
    int s=0, e=n-1;
    int mid=s+((e-s)/2);
    int ans=-1;
    while(s<=e){
        if(array[mid]==key){
            ans= mid;
            e=mid-1;
        }
        else if(array[mid]>key){
            e=mid-1;
        }
        else{
            s=mid+1;
        }
        mid=s+((e-s)/2);
    }
    return ans;
}
int last(int array[],int n, int key){
    int s=0, e=n-1;
    int mid=s+((e-s)/2);
    int ans=-1;
    while(s<=e){
        if(array[mid]==key){
            ans= mid;
            s=mid+1;
        }
        else if(array[mid]>key){
            e=mid-1;
        }
        else{
            s=mid+1;
        }
        mid=s+((e-s)/2);
    }
    return ans;
}
int main(){
    int even[8]={2,3,5,6,8,8,7,4};
    int total;
    total = last(even,8, 8)-first(even,8, 8)+1;
    cout<<total<<endl;
    return 0;
}

