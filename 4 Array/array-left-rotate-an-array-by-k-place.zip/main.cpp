#include <iostream>
using namespace std;

int main(){
    int k=3;
    int n=6;
    int arr[n]={5,1,6,8,7,2};
    
    if(k>=n){
        k=k%n;
    }else{
        k=k;
    }
    int temp[n];
    for(int i=k;i<=n;i++){
        temp[i-k]=arr[i];
    }
    for(int i=0;i<k;i++){
        temp[n-k+i]=arr[i];
    }
    for(int i=0;i<n;i++){
        cout<<temp[i]<<" ";
    }
    
    return 0;
}
