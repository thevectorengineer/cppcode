#include <iostream>
using namespace std;

int main(){
    int n=4, m=4;
    int Arr[n][m]={{0,1,1,1},{1,1,0,0},{1,1,1,1},{1,0,0,0}};
    
    int indexOfRowWithMax1s = -1 ;
    int maxCount = 0 ;
    
    for(int i = 0 ; i < n ; i++){
        int count = 0 ;
        for(int j = 0 ; j < m ; j++ ){
            if(Arr[i][j] == 1){
                count++ ;
            }
        }
        if(count > maxCount){
            maxCount = count ;
            indexOfRowWithMax1s = i ;
        }
    }
    cout<<indexOfRowWithMax1s<<" ";

    return 0;
}