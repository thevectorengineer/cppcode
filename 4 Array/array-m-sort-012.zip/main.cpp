#include <iostream>
using namespace std;
int main(){
    int n=5;
    int a[n]={0,2,0,2,1};
    
    int zero=0, one=0, two=0;
    for(int i=0;i<n;i++){
         if(a[i]==0){zero++;} //2
         else if(a[i]==1){one++;} //1
         else if(a[i]==2){two++;} //2
     }
    for(int j=0;j<n;j++){
        if(zero>0){ a[j]=0; zero--;}
        else if(zero==0 && one>0 && two>0){ a[j]=1; one--;}
        else if(zero==0 && one==0 && two>0){ a[j]=2; two--;}
        cout<<a[j]<<" ";
    }
    return 0;
}
