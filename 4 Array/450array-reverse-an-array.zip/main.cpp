#include <iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    
    int array[n];
    
    for(int i=0; i<n;i++){
        cin>>array[i];
    }
  	int s=0, e=n-1;
  	while(s<=e){
  	    int temp=array[s];
        array[s]=array[e];
        array[e]=temp;
        s++;
        e--;
  	}
    for(int i=0; i<n;i++){
        cout<<array[i]<<" ";
    }
    return 0;
}