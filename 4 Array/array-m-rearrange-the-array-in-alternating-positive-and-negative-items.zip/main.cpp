#include <iostream>
using namespace std;
int main(){
    int n=9;
    int Arr[n] = {9, 4, -2, -1, 5, 0, -5, -3, 2};
    int temp[n]={};
    for(int i=1;i<n;i++){
        temp[0]=Arr[0];
        if(Arr[i]>=0){
            
        }else{
            
        }
    }
    for(int i=0;i<n;i++){
        cout<<temp[i]<<" ";
    }
    return 0;
}