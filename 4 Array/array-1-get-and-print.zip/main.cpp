#include <iostream>
using namespace std;

int getArr(int gArr[], int size){
        for(int i=0; i<size;i++){
         cin>>gArr[i];
        }
        return 0;
}
int printArr(int pArr[], int size){
    for(int i=0; i<size;i++){
        cout<<pArr[i]<<" ";
    }
    return 0;
}

int main(){
    int arr[10];
    getArr(arr, 10);
    printArr(arr, 10);
    return 0;
}
