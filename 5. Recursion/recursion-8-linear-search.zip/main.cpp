#include <iostream>
using namespace std;
bool linear(int arr[], int size, int key){
    if(size==0){
        return false;
    }
    else{
        if(arr[0]==key){
            return true;
        }
        else{
            bool rem=linear(arr+1,size-1, key);
            return rem;
        }
    }
}

int main(){
   int arr[6]={2,5,8,12,34,56};
   int size=6;
   int key=18;
   bool ans=linear(arr, size, key);
   if(ans){
        cout<<"present. "<<endl;
   }
   else{
        cout<<"Absent."<<endl;
   }
   return 0;
}

