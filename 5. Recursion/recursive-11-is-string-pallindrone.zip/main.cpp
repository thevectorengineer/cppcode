#include <iostream>
using namespace std;

bool pallindrone(string& str, int i, int j){
    if(i>j){
        return true;
    }

    if(str[i]!=str[j])
        return false;
    else
        return pallindrone(str, i+1, j-1);
}

int main(){
    string name= "amaama";
    bool check =pallindrone(name, 0, name.length()-1);
    if(check)
        cout<<"Yes"<<endl;
    else
        cout<<"No"<<endl;
    return 0;
}