#include <iostream>
using namespace std;
void Rec_ins_sort(int *arr, int n, int i){
    if(i<n){
        int temp=arr[i];
        int j=i-1;
        for(;j>=0;j--){
           if(arr[j]>temp)
               arr[j+1]=arr[j];
            else
                break;
        }
        arr[j+1]=temp;
        i++;
        Rec_ins_sort(arr, n, i);
    }
}
int main() {
    int arr[7]={5,2,8,3,6,4,9};
    int n=7;
    Rec_ins_sort(arr, n, 1);
    for(int i=0; i<n;i++){
        cout<<arr[i]<<" "; 
    }cout<<endl;
}