#include <iostream>
using namespace std;
bool binary(int arr[], int s,int e, int key){
    if(s>e){
        return false;
    }
    int mid=s+(e-s)/2;
    if(arr[mid]==key){
        return true;
    }
    if(arr[mid]>key){
        return binary(arr,s,mid-1,key); 
    }
    else{
        return binary(arr, mid+1,e, key);
    }
}

int main(){
   int arr[6]={2,5,8,12,34,56};
   int key=34;
   bool ans=binary(arr, 0,6, key);
   if(ans){
        cout<<"Present"<<endl;
   }
   else{
        cout<<"Absent"<<endl;
   }
   return 0;
}

