#include <iostream>
using namespace std;
void Rec_bubble_sort(int *arr, int e){
    if(e==0) return;
    for(int i=0;i<e;i++){
        if(arr[i]>arr[i+1]){
            int temp=arr[i];
            arr[i]=arr[i+1];
            arr[i+1]=temp;
        }
    }
    Rec_bubble_sort(arr, e-1);
}
int main() {
    int arr[7]={5,2,8,3,6,4,9};
    int n=7;
    Rec_bubble_sort(arr, 6);
    for(int i=0; i<n;i++){
        cout<<arr[i]<<" "; // 
    }cout<<endl;
}