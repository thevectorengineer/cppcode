#include <iostream>
using namespace std;
void ghartolib(int ghar, int lib){
    cout<<"Ghar se "<<ghar<<" Library tk "<<lib<<endl;
    if(ghar==lib)
        return;
    ghar++;
   ghartolib(ghar, lib);
        
}
int main(){
    int lib=10;
    int ghar=1;
    ghartolib(ghar, lib);
    return 0;
}
