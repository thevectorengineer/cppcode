#include <iostream>
using namespace std;

void binarysort(int *str, int size){
    if(size==0 ||size==1){
        return;
    }
    for(int i=0; i<size;i++){
        if(str[i]>str[i+1]){
            swap(str[i],str[i+1]);
        }
    }
    binarysort(str, size-1);
}

int main(){
    int str[9]={2,6,4,8,9,1,3,5,7};
    binarysort(str, 9);
    for(int i=0; i<9;i++){
        cout<<str[i]<<" ";
    }
    return 0;
}