#include <iostream>
using namespace std;
bool method(string str, int i){
    if(i>str.size()/2){
        return true;
    }
    return str[i]==str[str.size()-i-1] && method(str, i+1);
}
int main(){
    string S="abba";
    int i=0;
    cout<<method(S, i);
    return 0;
}