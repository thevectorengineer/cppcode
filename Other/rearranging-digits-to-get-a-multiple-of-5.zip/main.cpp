#include <iostream>
using namespace std;

int main() {
	int t;
	cin>>t;
	while(t--){
	    int d;
	    cin>>d;
	    long long n=0;
	    int x;
	    for(int i=0;i<d;i++){
	        cin>>x;
	        n=n*10+x;
	    }
	    bool b=0;
	    while(d>0){
	        int rem=n%10;
	        if(rem==5 || rem==0){
	            b=1;
	            break;
	        }
	        n=n/10;
	        d--;
	    }
	    if(b==1) cout<<"YES"<<endl;
	    else cout<<"NO"<<endl;
	}
	return 0;
}
