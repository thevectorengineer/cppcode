#include <iostream>
using namespace std;

int main() {
	    int n,k; cin>>n;
            int ans=0;
            for(int i=0;i<n;i++){ 
                cin>>k; 
                cout<<"ans"<<ans<<endl;
                ans=ans^k; 
                cout<<"ans"<<ans<<endl;
                cout<<"k"<<k<<endl;
            }
            cout<<"ok"<<"\n";
	return 0;
}
