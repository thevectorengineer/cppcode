#include <iostream>
using namespace std;
int main(){
    int n;
    cin>>n; //5
    int a[n];
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    //BS= barabar wale se compare krna hota h. then swap, large number last m phle sort hota h.
    for(int c=1; c<n-1; c++){ //1-4
        for(int i=0;i<n-c;i++){ //0- 5-c > 0-3,0-2,0-1
            if(a[i]>a[i+1]){
                int temp=a[i];
                a[i]=a[i+1];
                a[i+1]=temp;
            }
        }
    }
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
    return 0;
}