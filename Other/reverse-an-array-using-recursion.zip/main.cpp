#include <iostream>
using namespace std;

void reverse(int l, int r, int arr[]){
    if(l>=r){
        return ;
    }
    swap(arr[l],arr[r]);
    reverse(l+1,r-1, arr);
}

int main() {
	//code
	int N;
	int arr[10];
	cin>>N;
	
	for(int i=1; i<=N; i++){
	    cin>>arr[i];
	}
	reverse(1,N, arr);
	for(int i=1; i<=N; i++){
	    cout<<arr[i]<<" ";
	}
	return 0;
}