#include <iostream>
using namespace std;
int main(){
    int n;
    cin>>n; //5
    int array[n];
    for(int i=0; i<n;i++){// 0 1 2 3 4
        cin>>array[i];   //  5 2 8 3 6
    }
    //IS= 1st wale ko sort smj kr next value ko insert krna hota h compare krke, snall phle sort ho jata h.
    for (int i = 1; i < n; i++){  //i=1
        int tmp = array[i];       //t=a1 t=2
        int j = i-1;
        for (; j >=0; j--){              //j=0
            if (array[j] > tmp)         // a0>t 5>2
                array[j+1] = array[j]; //  a1=a0 2 ki jagah 5   55836
            else
                break;
        }
        array[j+1] = tmp; // a1=t 25836  
    }
    for(int i=0; i<n;i++){
        cout<<array[i]<<" "; // 
    }cout<<endl;
    return 0;
}
