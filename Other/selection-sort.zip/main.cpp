#include <iostream>
using namespace std;
int main(){
    int n;
    cin>>n; //5
    int array[n]; //51826
    for(int i=0; i<n;i++){
        cin>>array[i];
    }
    //SS= small phle sort hota h, first wale ko smallest find krke swap krna hota h
    for(int i=0; i<n-1;i++){ // 0-3
        for(int j=i+1;j<n;j++){ //i+1-4} 1-4,2-4,3-4
            if(array[j]<array[i]){
                int temp=array[j];
                array[j]=array[i];
                array[i]=temp;
            }
        }
    }
    for(int i=0; i<n;i++){
        cout<<array[i]<<" ";
    }cout<<endl;
    return 0;
}
