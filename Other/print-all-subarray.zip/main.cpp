#include <iostream>
using namespace std;
void print(int *arr, int s, int e){
    for(int i=s; i<=e; i++){
        cout<<arr[i]<<" ";
    }cout<<endl;
}
int main(){
    int n=5;
    int arr[n]={2,4,6,8,10};
     for(int s=0; s<n;s++){
        for(int e=s;e<n;e++){
            print(arr,s,e);
        }
     }

    return 0;
}
