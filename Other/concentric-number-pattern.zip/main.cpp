#include <iostream>
using namespace std;
int main(){
    int n= 4;
    int s= 1;
    int e= 2*n-1; //7
    while(n!=0){
        for(int i=s; i<=e;i++){
            for(int j=s; j<=e;j++){
                if(i==s || i==e || j==s || j==e){
                    cout<<n<<" ";
                }
            }cout<<endl;
            ++s;
            --e;
            --n;
        }
    }
    return 0;
}
