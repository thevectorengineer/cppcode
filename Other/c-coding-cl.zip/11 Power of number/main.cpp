#include<iostream>
using namespace std;

int main() {
	// Write your code here
	 int power;
    float base, result = 1;

  
    cin >> base >> power;

    while (power != 0) {
        result *= base;
        --power;
    }

    cout << result;
}
