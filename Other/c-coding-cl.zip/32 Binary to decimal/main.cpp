#include<iostream>
using namespace std;
int main ()
{
    int num, rem, dec = 0, b = 1;
    cin >> num;
    
    while (num > 0)
    {
        rem = num % 10;
        dec = dec + rem * b;
        b *= 2;
        num /= 10;
    }
    cout<< dec;
    return 0;
}