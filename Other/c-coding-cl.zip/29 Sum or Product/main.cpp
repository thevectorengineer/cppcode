#include <iostream>
using namespace std;

int main()
{
int N, Q;
int sum=0;
long int mul=1;

cin>>N;
cin>>Q;

    if(Q==1){
        for(int i=1; i<=N;i++){
        sum=sum+i;
        }
    cout<<sum;
    }

    else if(Q==2){
        for(int i=1; i<=N;i++){
        mul=mul*i;
        mul=mul%1000000007;
        }
    cout<<mul;
    }

    else{
        cout<<-1;
    }
    return 0;
}
