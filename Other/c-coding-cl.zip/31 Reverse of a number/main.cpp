#include<iostream>
using namespace std;

int main() {
	// Write your code here
	 int n, reversedNumber = 0;
	 int rem;

    cin >> n;

    while(n != 0) {
        rem = n%10;
        reversedNumber = reversedNumber*10 + rem;
        n /= 10;
    }

    cout << reversedNumber;
}
