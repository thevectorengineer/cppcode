#include<iostream>
using namespace std;
int main()
{
int i,j,sum=0,n;
cin>>n;
for(i=1; i<=n; i++)
{
for(j=1; j<=i; j++)
{
sum = sum + j;
cout<<j;//programology content
(j==i) ? cout<<"="<<sum : cout<<"+";
}
cout<<endl;
sum=0;
}
return 0;
}
