#include<iostream>
using namespace std;

int main() {
	// Write your code here
	
    long int n;
    int sum=0;
    
    cin>>n;
    cout<<endl;
    
    for(int i=1 ; i<=n ; i++){
         if(i%2==0){
            sum= sum+i;
         }   
    }
    cout<<sum;
	return 0;
}

