/*Printing pattern
*/
#include<iostream>
using namespace std;

int main()
{
    int i,j,k,r;
    cin >> r;

    
   for(i=1;i<=(r+1)/2;i++)
   {
     for(j=1;j<=((r+1)/2)-i;j++)
     {
        cout<<" ";
     }
     for(k=1;k<=2*i-1;k++)
     {
        cout<<"*";
     }
     cout<<endl;
   }
   
   for(i=((r+1)/2)-1;i>=1;i--)
   {
     for(j=1;j<=((r+1)/2)-i;j++)
     {
        cout<<" ";
     }
     for(k=1;k<=2*i-1;k++)
     {
        cout<<"*";
     }
     cout<<endl;
   }
   
}
