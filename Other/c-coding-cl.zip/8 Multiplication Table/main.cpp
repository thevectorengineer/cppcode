#include<iostream>
using namespace std;

int main() {
	// Write your code here
	int n, i;
    cin>>n;
    for (i = 1; i <= 10; ++i) {
        cout<<n*i<<endl;
    }
}