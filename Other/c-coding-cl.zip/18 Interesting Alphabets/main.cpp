/*Printing pattern
E
DE
CDE
BCDE
ABCDE
*/
#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;

    int i=1;
    while (i<=n){
        int j=1;
        char p = (char)('A' + n-i);
        while(j<=i){
            cout<<p;
            p=(char)(p+1);
            j++;
        }
        cout<<endl;
        i++;
    }
    return 0;
}