#include<iostream>
using namespace std;

int main()
{
    int N,num,i;
    cin>>N;
    for(num=2;num<=N;num++){
        for (i = 2; i <num; i++){
            if (num%i==0){
                break;
            }
        } 
        if (i==num){
            cout<<num<<endl;
        }
    }
    return 0;
}
