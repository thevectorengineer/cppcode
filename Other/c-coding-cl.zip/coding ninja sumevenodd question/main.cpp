/*
    Time Complexity: O(N)
    Space Complexity: O(1)

    Where 'N' is the number of digits in the given input.
*/

vector<int> sumOfEvenOdd(long long num) 
{
	int evenSum = 0;
    int oddSum = 0;
    vector<int> ans;

	while(num > 0)
	{

        // Storing the one's place digit in 'last'.
		int last = num % 10;

        // Digit is even.
		if(last % 2 == 0) 
		{
			evenSum = evenSum + last;
		}

        // Digit is odd.
		else 
		{
			oddSum = oddSum + last;
		}

        // Removing the one's place digit from 'num'.
		num = num / 10;
	}

    ans.push_back(evenSum);
    ans.push_back(oddSum);

    return ans;
}