#include<iostream>
using namespace std;
 int main()
{
int a=1, b, c=1, i, j, k, n;
cin>>n;

for(i=n; i>=1; i--)
{
    b=a;
    c=1;
    for(j=i; j>=1; j--)
    {
        cout<<b;
        b+=2;
    }
    for(k=n-i; k>0; k--)
    {
        cout<<c;
        c+=2;//programology content
    }
cout<<endl;
a+=2;
}
return 0;
}