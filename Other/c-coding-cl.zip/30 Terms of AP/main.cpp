#include<iostream>
using namespace std;

int main() {
  int n,s;
  cin>>n;
  for(int i=1;i<=10000;i++) {
       if(n!=0){
            s=(3*i)+2;
            if(s%4!=0){
               cout<<s<<" ";
               n--;
           }
        }
    }
}