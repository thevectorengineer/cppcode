#include<iostream>
using namespace std;

int main(){


    char str;
  int Dc=0, Cc=0, Sc=0;
    
    str=cin.get();
    
     while(str != '$'){
        if( str >='0' && str <='9'){
         Dc++;   
            str=cin.get();
        }
        else if( str >='a' && str <='z'){
         Cc++;   
            str=cin.get();
        }
        else if(str == ' ' && str =='\n' && str =='\t' ){
            Sc++;
            str=cin.get();
        }
    }
    cout <<Cc <<" "<<Dc<<" "<<Sc;
    return 0;
  
}