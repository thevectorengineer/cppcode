#include<iostream>
using namespace std;

int main() {
	// Write your code here
	int i, j, N;

    cin>>N;

    cout<<"*\n";
    // Print the first upper half
    for(i=1; i<=N; i++)
    {
        cout<<"*";
        for(j=1; j<=i; j++)
        {
            cout<<j;
        }
        for(j=i-1; j>=1; j--)
        {
            cout<<j;
        }
        cout<<"*";
        cout<<endl;
    }

    // Print the lower half of the pattern
    for(i=N-1; i>=1; i--)
    {
        cout<<"*";
        for(j=1; j<=i; j++)
        {
            cout<<j;
        }
        for(j=i-1; j>=1; j--)
        {
            cout<<j;
        }
        cout<<"*";

        cout<<endl;
    }
    cout<<"*";
}
