#include <iostream>
using namespace std;

int main()
{
    int x;
    int sq = 1;
    cin>>x;
    if (x == 0 || x == 1){
        cout<< x;
    }
    else{
    int i = 1;
    while (sq <= x){
      i++;
      sq = i * i;
    }
    cout<< i - 1;
    }
}