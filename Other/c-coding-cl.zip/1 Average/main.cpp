#include<iostream>
using namespace std;


int main(){

    // Write your code here.
    char a;
    int m1, m2, m3;
    int avg;
    
    cin>>a;
    cin>>m1 >> m2>> m3;
    avg=(m1+m2+m3)/3;
    
    std::cout<<a<<endl;
    std::cout<<avg<<endl;
  
}
