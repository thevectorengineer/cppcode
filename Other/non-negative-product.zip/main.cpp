#include <iostream>
using namespace std;

int main() {
	int t;
	cin>>t;
	while(t--){
	    int d;
	    cin>>d;
	    long long a[d]={};
	    for(int i=0;i<d;i++){
	        cin>>a[i];
	    }
	    int ans=1;
	    for(int i=0;i<d;i++){
	        ans=ans*a[i];
	    }
	   if(ans<0) cout<<0<<endl;
	   else cout<<1<<endl;
	}
	return 0;
}