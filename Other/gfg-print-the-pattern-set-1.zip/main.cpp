#include <iostream>
using namespace std;
int main(){
   int n=3;
    for (int i=n; i>0; i--){
        for(int j=n;j>0;j--){
            for(int k=0;k<i;k++){
                cout<<j<< " ";
            }     
        }
        cout<<"$";
    }
    return 0;
}