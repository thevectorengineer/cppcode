#include<iostream>
using namespace std;

class Node {
    public:
    int data;
    Node* address;
    //constructor
    Node(int deta) {
        this -> data = deta;
        this -> address = NULL;
    }
};
void insertAtHead(Node* &head, int d){
     //new node which will insertAtHead
     Node* inserted= new Node(d);
     
     inserted ->address=head;
     head=inserted;
    
}
void print(Node* &head){
    Node* printer=head;
    while(printer!=NULL){
        cout<<printer ->data<<" ";
        printer = printer ->address;
    }cout<<endl;
}
int main(){
    //created a new node
    Node* node1 = new Node(9);
    Node* head = node1; 
    print(head);
    insertAtHead(head, 6);
    print(head);
    insertAtHead(head, 3);
    print(head);
}
