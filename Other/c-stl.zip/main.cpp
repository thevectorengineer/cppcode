#include <bits/stdc++.h>
using namespace std;
int main(){
    cout<<"STD"<<endl;
    //1. Algorithm,
    //2. Function,
    //3. Container,
    //4. Iterator.
    
    //PAIR
    cout<<"PAIR"<<endl;
    pair <int, int> p1 ={1,2};
    cout<<p1.first<<" "<<p1.second<<endl;

    pair <int, pair <int, int>> p2 ={1,{3,4}};
    cout<<p2.first<<" "<<p2.second.first<<" "<<p2.second.second<<endl;
    
    //VECTOR
    cout<<"VECTOR"<<endl;
    vector<int> v;  // empty array
    v.push_back(9); // {9}
    v.push_back(1); // {9,1}
    v.push_back(3); // {9,1,3}
    v.push_back(5); // {9,1,3,5}
    v.push_back(7); // {9,1,3,5,7}
    v.emplace_back(111); //{9,1,3,5,7,8}
    for(auto it:v)  // LOOP
        cout<<it<<" ";
    cout<<endl;
    v.pop_back(); //POP last element {9}
    for(auto it:v)
        cout<<it<<" ";
    cout<<endl;
    vector<int> v1(5,100); // {100,100,100,100,100}
    for(auto i:v1) 
        cout<<i<<" ";
    cout<<endl;
    vector<int> v2(5); // {0,0,0,0,0}
    for(auto i:v2) 
        cout<<i<<" ";
    cout<<endl;
    vector<int> v3(v); // {9} COPY ARRAY
    for(auto i:v3) 
        cout<<i<<" ";
    cout<<endl;
    //iterating in vector
    vector<int>::iterator I=v.begin(); //iterate an element
        cout<<*(I)<<" "<<endl; //9
        I++;
        cout<<*(I)<<" "<<endl; //1
        I=I+2;
        cout<<*(I)<<" "<<endl; //5
    vector<int>::iterator I1=v.end(); //iterate an element
        cout<<*(I1)<<" "<<endl; //111
        I1--;
        cout<<*(I1)<<" "<<endl; //7
        cout<<v.back()<<" "<<endl; //7 LAST ELEMENT
    for(vector<int>::iterator a=v.begin(); a!=v.end(); a++){ // iterate from start to end-1
        cout<<*(a)<<" "; 
    }cout<<endl;
    for(auto a=v.begin(); a!=v.end(); a++){ // iterate from start to end-1
        cout<<*(a)<<" ";   
    }cout<<endl;
    
    return 0;
}